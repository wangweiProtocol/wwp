<?php
// WangWei Protocol (WWP) Gateway v1.0
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json');

define('INBOX_FILE', __DIR__ . '/inbox.json');
define('PRIVATE_KEY_FILE', __DIR__ . '/private-key.pem');
define('DEEPSEEK_API_KEY', 'sk-04a48147ae0744c291c4d942311c2672');   // 替换为真实Key

function aiReply($message) {
    $url = 'https://api.deepseek.com/v1/chat/completions';
    $payload = [
        'model' => 'deepseek-chat',
        'messages' => [
            ['role' => 'system', 'content' => '你是一个友好的AI助手，收到一条消息，请根据内容生成一句简短、自然的回复。回复不要超过50字。'],
            ['role' => 'user', 'content' => $message]
        ],
        'max_tokens' => 100,
        'temperature' => 0.8
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . DEEPSEEK_API_KEY
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $resp = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($resp, true);
    return trim($data['choices'][0]['message']['content'] ?? "谢谢你的消息！");
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $_GET['action'] ?? ($input['action'] ?? '');

// 发送消息
if ($action === 'send') {
    $to = $input['to'] ?? '';
    $content = $input['content'] ?? '';
    if (!$to || !$content) exit(json_encode(['success' => false, 'error' => 'Missing params']));
    $from = 'sender#' . $_SERVER['HTTP_HOST'];
    $timestamp = time();
    $data = $from . $to . $content . $timestamp;
    $hash = hash('sha256', $data, true);
    $privateKey = openssl_pkey_get_private('file://' . PRIVATE_KEY_FILE);
    if (!$privateKey) exit(json_encode(['success' => false, 'error' => 'Private key error']));
    openssl_sign($hash, $signature, $privateKey, OPENSSL_ALGO_SHA256);
    $payload = [
        'from' => $from,
        'to' => $to,
        'content' => $content,
        'timestamp' => $timestamp,
        'signature' => base64_encode($signature)
    ];
    $targetDomain = explode('#', $to)[1];
    $targetUrl = "https://$targetDomain/deepseek/wwp/";
    $ch = curl_init($targetUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $resp = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    exit(json_encode(['success' => true, 'http_code' => $httpCode, 'response' => $resp]));
}

// 接收消息
if ($input && isset($input['from']) && isset($input['to']) && isset($input['content']) && isset($input['timestamp']) && isset($input['signature'])) {
    $from = $input['from'];
    $to = $input['to'];
    $content = $input['content'];
    $timestamp = $input['timestamp'];
    $signature = base64_decode($input['signature']);
    $parts = explode('#', $from);
    if (count($parts) != 2) exit(json_encode(['error' => 'Invalid from']));
    $fromDomain = $parts[1];
    $pubKeyUrl = "https://$fromDomain/deepseek/wwp/public-key.pem";
    $pubKeyPem = @file_get_contents($pubKeyUrl);
    if (!$pubKeyPem) exit(json_encode(['error' => 'Cannot get public key']));
    $pubKey = openssl_pkey_get_public($pubKeyPem);
    $data = $from . $to . $content . $timestamp;
    $hash = hash('sha256', $data, true);
    $valid = openssl_verify($hash, $signature, $pubKey, OPENSSL_ALGO_SHA256);
    if ($valid !== 1) exit(json_encode(['error' => 'Signature invalid']));
    // 存储消息
    $inbox = [];
    if (file_exists(INBOX_FILE)) $inbox = json_decode(file_get_contents(INBOX_FILE), true);
    $inbox[] = $input;
    file_put_contents(INBOX_FILE, json_encode($inbox, JSON_PRETTY_PRINT));
    // AI 回复（仅当不是机器人发送时）
    if (strpos($from, 'ai-bot#') === false && strpos($from, 'reply-bot#') === false) {
        $aiReply = aiReply($content);
        $replyFrom = 'ai-bot#' . $_SERVER['HTTP_HOST'];
        $replyTo = $from;
        $replyTimestamp = time();
        $replyData = $replyFrom . $replyTo . $aiReply . $replyTimestamp;
        $replyHash = hash('sha256', $replyData, true);
        $privateKey = openssl_pkey_get_private('file://' . PRIVATE_KEY_FILE);
        if ($privateKey) {
            openssl_sign($replyHash, $replySignature, $privateKey, OPENSSL_ALGO_SHA256);
            $replyPayload = [
                'from' => $replyFrom,
                'to' => $replyTo,
                'content' => $aiReply,
                'timestamp' => $replyTimestamp,
                'signature' => base64_encode($replySignature)
            ];
            $targetDomain = explode('#', $replyTo)[1];
            $targetUrl = "https://$targetDomain/deepseek/wwp/";
            $ch = curl_init($targetUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($replyPayload));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_exec($ch);
            curl_close($ch);
        }
    }
    exit(json_encode(['success' => true, 'message' => 'Processed']));
}

// 查询收件箱
if ($action === 'inbox') {
    $inbox = [];
    if (file_exists(INBOX_FILE)) $inbox = json_decode(file_get_contents(INBOX_FILE), true);
    exit(json_encode(['success' => true, 'messages' => $inbox]));
}

exit(json_encode(['error' => 'Invalid request']));
?>