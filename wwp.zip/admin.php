<?php
// adminwanjia178.php - 管理中心（用户管理 + 公告管理）
session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

$db = DB::get();
$error = null;

// 处理登录
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    if ($user === ADMIN_USER && $pass === ADMIN_PASS) {
        $_SESSION['admin_logged'] = true;
    } else {
        $error = '用户名或密码错误';
    }
}

// 检查登录状态
if (!isset($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    // 显示登录表单
    ?>
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"><title>管理员登录 - WWP</title><link rel="stylesheet" href="style.css"><style>body{display:flex;justify-content:center;align-items:center;min-height:100vh;}</style></head>
    <body>
    <div class="glass-card" style="padding: 32px; width: 320px;">
        <h2>🔐 管理中心登录</h2>
        <?php if ($error): ?><div class="error-message"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <form method="post">
            <input type="text" name="username" placeholder="用户名" required><br><br>
            <input type="password" name="password" placeholder="密码" required><br><br>
            <button type="submit" name="login" class="btn-neon btn-primary">登录</button>
        </form>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// 处理公告操作
$announcement_action = $_GET['announcement_action'] ?? '';
if ($announcement_action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($title && $content) {
        $stmt = $db->prepare("INSERT INTO announcements (title, content, created_at) VALUES (?, ?, ?)");
        $stmt->execute([$title, $content, time()]);
    }
    header('Location: adminwanjia178.php?tab=announcements');
    exit;
}
if ($announcement_action === 'edit' && isset($_GET['id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_GET['id']);
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($title && $content) {
        $stmt = $db->prepare("UPDATE announcements SET title = ?, content = ? WHERE id = ?");
        $stmt->execute([$title, $content, $id]);
    }
    header('Location: adminwanjia178.php?tab=announcements');
    exit;
}
if ($announcement_action === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $db->prepare("DELETE FROM announcements WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: adminwanjia178.php?tab=announcements');
    exit;
}

// 处理用户操作（删除用户等）
$action = $_GET['action'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 20;
$search = trim($_GET['search'] ?? '');

if ($action === 'delete_user' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $db->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $stmt2 = $db->prepare("DELETE FROM messages WHERE to_username = ?");
        $stmt2->execute([$user['username']]);
    }
    $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: adminwanjia178.php?tab=users&page=' . $page . '&search=' . urlencode($search));
    exit;
}
if ($action === 'delete_message' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $db->prepare("DELETE FROM messages WHERE id = ?");
    $stmt->execute([$id]);
    $userId = intval($_GET['user_id'] ?? 0);
    header('Location: adminwanjia178.php?tab=users&user_id=' . $userId . '&page=' . $page . '&search=' . urlencode($search));
    exit;
}

// 用户列表查询
$countSql = "SELECT COUNT(*) FROM users WHERE 1=1";
$listSql = "SELECT id, username, created_at FROM users WHERE 1=1";
$params = [];
if ($search !== '') {
    $countSql .= " AND username LIKE ?";
    $listSql .= " AND username LIKE ?";
    $params[] = "%$search%";
}
$stmt = $db->prepare($countSql);
foreach ($params as $i => $p) $stmt->bindValue($i+1, $p);
$stmt->execute();
$totalUsers = $stmt->fetchColumn();
$totalPages = ceil($totalUsers / $perPage);
$offset = ($page - 1) * $perPage;
$listSql .= " ORDER BY id DESC LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;
$stmt = $db->prepare($listSql);
foreach ($params as $i => $p) $stmt->bindValue($i+1, $p);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$selectedUserId = isset($_GET['user_id']) ? intval($_GET['user_id']) : null;
$selectedUser = null;
$userMessages = [];
if ($selectedUserId) {
    $stmt = $db->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$selectedUserId]);
    $selectedUser = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($selectedUser) {
        $stmt = $db->prepare("SELECT * FROM messages WHERE to_username = ? ORDER BY created_at DESC");
        $stmt->execute([$selectedUser['username']]);
        $userMessages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// 公告列表
$announcements = $db->query("SELECT id, title, content, created_at FROM announcements ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
$currentTab = $_GET['tab'] ?? 'users';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>管理中心 - WWP</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .admin-container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .tabs { display: flex; gap: 16px; margin-bottom: 20px; border-bottom: 1px solid var(--border-glow); padding-bottom: 8px; }
        .tab { padding: 8px 20px; border-radius: 30px; background: rgba(0,0,0,0.3); text-decoration: none; color: #0ff; }
        .tab.active { background: var(--neon-cyan); color: #010515; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid var(--border-glow); padding: 10px; text-align: left; }
        th { background: rgba(0,255,255,0.1); }
        .pagination { margin-top: 20px; display: flex; gap: 8px; flex-wrap: wrap; }
        .pagination a, .pagination span { padding: 6px 12px; background: rgba(0,0,0,0.5); border-radius: 20px; text-decoration: none; color: #0ff; }
        .pagination .current { background: #0ff; color: #010515; }
        .search-form { margin-bottom: 20px; display: flex; gap: 12px; align-items: center; }
        .edit-form { background: rgba(0,0,0,0.3); padding: 20px; border-radius: 20px; margin-bottom: 20px; }
        .edit-form input, .edit-form textarea { width: 100%; margin-bottom: 10px; }
        button.btn-neon { background: rgba(0,255,255,0.1); border: 1px solid #0ff; color: #0ff; padding: 6px 16px; border-radius: 20px; cursor: pointer; }
        button.btn-primary { background: #0ff; color: #010515; }
        .action-buttons { display: flex; gap: 8px; }
    </style>
</head>
<body>
<div class="admin-container">
    <h1>👑 WWP 管理中心</h1>
    <p>欢迎，管理员 | <a href="?logout=1" style="color:#0ff">退出登录</a></p>
    <?php if (isset($_GET['logout'])) { session_destroy(); header('Location: adminwanjia178.php'); exit; } ?>

    <div class="tabs">
        <a href="?tab=users" class="tab <?= $currentTab === 'users' ? 'active' : '' ?>">用户管理</a>
        <a href="?tab=announcements" class="tab <?= $currentTab === 'announcements' ? 'active' : '' ?>">公告管理</a>
    </div>

    <?php if ($currentTab === 'users'): ?>
        <div class="search-form">
            <form method="get" style="display: flex; gap: 12px; align-items: center;">
                <input type="hidden" name="tab" value="users">
                <input type="text" name="search" placeholder="搜索用户名" value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn-neon">搜索</button>
            </form>
        </div>

        <h2>用户列表 (共 <?= $totalUsers ?> 人)</h2>
        <table>
            <thead><tr><th>ID</th><th>用户名</th><th>注册时间</th><th>操作</th></tr></thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><a href="?tab=users&user_id=<?= $u['id'] ?>&page=<?= $page ?>&search=<?= urlencode($search) ?>"><?= htmlspecialchars($u['username']) ?></a></td>
                    <td><?= date('Y-m-d H:i:s', $u['created_at']) ?></td>
                    <td><a href="?tab=users&action=delete_user&id=<?= $u['id'] ?>&page=<?= $page ?>&search=<?= urlencode($search) ?>" onclick="return confirm('确定删除用户及其所有邮件？')">删除</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="current"><?= $i ?></span>
                <?php else: ?>
                    <a href="?tab=users&page=<?= $i ?>&search=<?= urlencode($search) ?><?= $selectedUserId ? '&user_id=' . $selectedUserId : '' ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>

        <?php if ($selectedUser): ?>
            <h2>📬 用户 <?= htmlspecialchars($selectedUser['username']) ?> 的邮件列表</h2>
            <table>
                <thead><tr><th>ID</th><th>发件人</th><th>主题</th><th>内容预览</th><th>时间</th><th>操作</th></tr></thead>
                <tbody>
                    <?php foreach ($userMessages as $msg): ?>
                    <tr>
                        <td><?= $msg['id'] ?></td>
                        <td><?= htmlspecialchars($msg['from_username']) ?></td>
                        <td><?= htmlspecialchars($msg['subject'] ?: '(无主题)') ?></td>
                        <td><?= htmlspecialchars(mb_substr($msg['content'], 0, 50)) ?>…</td>
                        <td><?= date('Y-m-d H:i:s', $msg['created_at']) ?></td>
                        <td><a href="?tab=users&action=delete_message&id=<?= $msg['id'] ?>&user_id=<?= $selectedUserId ?>&page=<?= $page ?>&search=<?= urlencode($search) ?>" onclick="return confirm('删除此邮件？')">删除</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <a href="?tab=users&page=<?= $page ?>&search=<?= urlencode($search) ?>" class="btn-neon">← 返回用户列表</a>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($currentTab === 'announcements'): ?>
        <h2>📢 公告管理</h2>
        <div class="edit-form">
            <h3>添加新公告</h3>
            <form method="post" action="?announcement_action=add&tab=announcements">
                <input type="text" name="title" placeholder="标题" required>
                <textarea name="content" rows="5" placeholder="内容" required></textarea>
                <button type="submit" class="btn-neon btn-primary">发布公告</button>
            </form>
        </div>

        <h3>现有公告</h3>
        <table>
            <thead><tr><th>ID</th><th>标题</th><th>内容预览</th><th>发布时间</th><th>操作</th></tr></thead>
            <tbody>
                <?php foreach ($announcements as $ann): ?>
                <tr>
                    <td><?= $ann['id'] ?></td>
                    <td><?= htmlspecialchars($ann['title']) ?></td>
                    <td><?= htmlspecialchars(mb_substr($ann['content'], 0, 50)) ?>…</td>
                    <td><?= date('Y-m-d H:i:s', $ann['created_at']) ?></td>
                    <td class="action-buttons">
                        <a href="?tab=announcements&edit_id=<?= $ann['id'] ?>" class="btn-neon" style="font-size:0.8rem;">编辑</a>
                        <a href="?announcement_action=delete&id=<?= $ann['id'] ?>&tab=announcements" onclick="return confirm('确定删除？')" class="btn-neon" style="font-size:0.8rem;">删除</a>
                    </td>
                </tr>
                <?php if (isset($_GET['edit_id']) && $_GET['edit_id'] == $ann['id']): ?>
                <tr>
                    <td colspan="5">
                        <form method="post" action="?announcement_action=edit&id=<?= $ann['id'] ?>&tab=announcements" style="padding: 10px; background: rgba(0,0,0,0.3); border-radius: 16px;">
                            <input type="text" name="title" value="<?= htmlspecialchars($ann['title']) ?>" required>
                            <textarea name="content" rows="5" required><?= htmlspecialchars($ann['content']) ?></textarea>
                            <button type="submit" class="btn-neon">保存修改</button>
                            <a href="?tab=announcements" class="btn-neon">取消</a>
                        </form>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>