<?php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

$db = DB::get();
$action = $_REQUEST['action'] ?? '';

// 验证码生成
if ($action === 'captcha') {
    $num1 = rand(1, 20);
    $num2 = rand(1, 20);
    $op = rand(0, 1) ? '+' : '-';
    $result = ($op === '+') ? $num1 + $num2 : $num1 - $num2;
    $_SESSION['captcha_result'] = $result;
    echo json_encode(['question' => "$num1 $op $num2 = ?"]);
    exit;
}

// 注册（请确保您的注册代码已完整）
if ($action === 'register') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $captcha = intval($_POST['captcha'] ?? 0);
    if ($captcha !== ($_SESSION['captcha_result'] ?? 0)) {
        echo json_encode(['success' => false, 'error' => '验证码错误']);
        exit;
    }
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        echo json_encode(['success' => false, 'error' => '用户名只能包含字母、数字、下划线']);
        exit;
    }
    if (strlen($password) < 4) {
        echo json_encode(['success' => false, 'error' => '密码至少4位']);
        exit;
    }
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => '用户名已存在']);
        exit;
    }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO users (username, password, created_at) VALUES (?, ?, ?)");
    $stmt->execute([$username, $hash, time()]);
    echo json_encode(['success' => true]);
    exit;
}

// 登录
if ($action === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $captcha = intval($_POST['captcha'] ?? 0);
    if ($captcha !== ($_SESSION['captcha_result'] ?? 0)) {
        echo json_encode(['success' => false, 'error' => '验证码错误']);
        exit;
    }
    $stmt = $db->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user || !password_verify($password, $user['password'])) {
        echo json_encode(['success' => false, 'error' => '用户名或密码错误']);
        exit;
    }
    $_SESSION['user'] = $username;
    echo json_encode(['success' => true]);
    exit;
}

// 获取收件箱（分页）
if ($action === 'get_messages') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $page = max(1, intval($_GET['page'] ?? 1));
    $perPage = 10;
    $offset = ($page - 1) * $perPage;
    $stmt = $db->prepare("SELECT COUNT(*) FROM messages WHERE to_username = ?");
    $stmt->execute([$_SESSION['user']]);
    $total = $stmt->fetchColumn();
    $stmt = $db->prepare("SELECT id, from_username, subject, content, is_read, created_at FROM messages WHERE to_username = ? ORDER BY created_at DESC LIMIT ? OFFSET ?");
    $stmt->execute([$_SESSION['user'], $perPage, $offset]);
    $msgs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'messages' => $msgs, 'total' => $total, 'page' => $page, 'per_page' => $perPage]);
    exit;
}

// 获取发件箱（分页）
if ($action === 'get_sent') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $page = max(1, intval($_GET['page'] ?? 1));
    $perPage = 10;
    $offset = ($page - 1) * $perPage;
    $stmt = $db->prepare("SELECT COUNT(*) FROM messages WHERE from_username = ? AND (parent_id = 0 OR parent_id IS NULL)");
    $stmt->execute([$_SESSION['user']]);
    $total = $stmt->fetchColumn();
    $stmt = $db->prepare("SELECT id, to_username, subject, content, created_at FROM messages WHERE from_username = ? AND (parent_id = 0 OR parent_id IS NULL) ORDER BY created_at DESC LIMIT ? OFFSET ?");
    $stmt->execute([$_SESSION['user'], $perPage, $offset]);
    $sent = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'messages' => $sent, 'total' => $total, 'page' => $page, 'per_page' => $perPage]);
    exit;
}

// 获取单条消息
if ($action === 'get_message') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $id = intval($_GET['id'] ?? 0);
    $stmt = $db->prepare("SELECT from_username, subject, content, created_at FROM messages WHERE id = ? AND to_username = ?");
    $stmt->execute([$id, $_SESSION['user']]);
    $msg = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($msg) {
        $stmt2 = $db->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
        $stmt2->execute([$id]);
        echo json_encode(['success' => true, 'message' => $msg]);
    } else {
        echo json_encode(['success' => false, 'error' => '消息不存在']);
    }
    exit;
}

// 获取回复历史
if ($action === 'get_replies') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $parent_id = intval($_GET['parent_id'] ?? 0);
    if (!$parent_id) {
        echo json_encode(['success' => false, 'error' => '缺少参数']);
        exit;
    }
    $stmt = $db->prepare("SELECT id, from_username, content, created_at FROM messages WHERE parent_id = ? ORDER BY created_at ASC");
    $stmt->execute([$parent_id]);
    $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'replies' => $replies]);
    exit;
}

// 发送回复
if ($action === 'send_reply') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $parent_id = intval($_POST['parent_id'] ?? 0);
    $to = trim($_POST['to'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if (!$parent_id || !$to || !$content) {
        echo json_encode(['success' => false, 'error' => '参数不足']);
        exit;
    }
    $stmt = $db->prepare("INSERT INTO messages (to_username, from_username, subject, content, parent_id, created_at) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$to, $_SESSION['user'], '回复消息', $content, $parent_id, time()]);
    echo json_encode(['success' => true, 'message' => '回复已发送']);
    exit;
}

// 发新消息（跨站）
if ($action === 'send_new') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $to = trim($_POST['to'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if (!$to || !$content) {
        echo json_encode(['success' => false, 'error' => '收件人和内容不能为空']);
        exit;
    }
    $fullContent = "主题：$subject\n\n$content";
    $from = $_SESSION['user'] . '#' . SITE_DOMAIN;
    $timestamp = time();
    $data = $from . $to . $fullContent . $timestamp;
    $hash = hash('sha256', $data, true);
    $privateKey = openssl_pkey_get_private('file://' . __DIR__ . '/private-key.pem');
    if (!$privateKey) {
        echo json_encode(['success' => false, 'error' => '私钥加载失败']);
        exit;
    }
    openssl_sign($hash, $signature, $privateKey, OPENSSL_ALGO_SHA256);
    $payload = [
        'from' => $from,
        'to' => $to,
        'content' => $fullContent,
        'timestamp' => $timestamp,
        'signature' => base64_encode($signature)
    ];
    $targetDomain = explode('#', $to)[1];
    $targetUrl = "https://$targetDomain/deepseek/wwp/";
    $ch = curl_init($targetUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $resp = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    // 本地存储发送记录
    $stmt = $db->prepare("INSERT INTO messages (to_username, from_username, subject, content, parent_id, created_at) VALUES (?, ?, ?, ?, 0, ?)");
    $stmt->execute([$to, $_SESSION['user'], $subject, $fullContent, time()]);
    echo json_encode(['success' => true, 'http_code' => $httpCode, 'response' => $resp]);
    exit;
}

// 获取 AI 对话历史
if ($action === 'get_ai_history') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $stmt = $db->prepare("SELECT role, content, created_at FROM ai_chat_history WHERE username = ? ORDER BY created_at ASC");
    $stmt->execute([$_SESSION['user']]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'history' => $history]);
    exit;
}

// 清除 AI 聊天历史
if ($action === 'clear_chat_history') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $username = $_SESSION['user'];
    $stmt = $db->prepare("DELETE FROM ai_chat_history WHERE username = ?");
    $stmt->execute([$username]);
    echo json_encode(['success' => true, 'message' => '聊天记录已清空']);
    exit;
}

// 辅助函数：调用 DeepSeek
function callDeepSeek($prompt) {
    $apiKey = DEEPSEEK_API_KEY;
    $url = 'https://api.deepseek.com/v1/chat/completions';
    $payload = [
        'model' => 'deepseek-chat',
        'messages' => [['role' => 'user', 'content' => $prompt]],
        'max_tokens' => 500,
        'temperature' => 0.7
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $resp = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode !== 200) {
        return ['error' => "DeepSeek API 错误 ($httpCode)"];
    }
    $data = json_decode($resp, true);
    return ['reply' => $data['choices'][0]['message']['content'] ?? ''];
}

// AI 聊天（支持按内容批量修改、按ID修改）
if ($action === 'ai_chat') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $username = $_SESSION['user'];
    $userMessage = trim($_POST['message'] ?? '');
    if (!$userMessage) {
        echo json_encode(['success' => false, 'error' => '消息为空']);
        exit;
    }

    // 保存用户消息到 AI 对话历史
    $db = DB::get();
    $stmt = $db->prepare("INSERT INTO ai_chat_history (username, role, content, created_at) VALUES (?, 'user', ?, ?)");
    $stmt->execute([$username, $userMessage, time()]);

    // 获取用户最近的邮件（前20条，供AI参考）
    $stmt = $db->prepare("SELECT id, from_username, subject, content, created_at FROM messages WHERE to_username = ? ORDER BY created_at DESC LIMIT 20");
    $stmt->execute([$username]);
    $recentMails = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $mailListText = "";
    foreach ($recentMails as $mail) {
        $mailListText .= "ID:{$mail['id']} 来自 {$mail['from_username']} 主题:{$mail['subject']} 内容预览:" . mb_substr($mail['content'], 0, 50) . "...\n";
    }

    $prompt = "你是一个智能助手，用户 $username 要求：$userMessage\n\n";
    $prompt .= "用户最近的邮件列表（供参考）：\n$mailListText\n";
    $prompt .= "请根据用户指令执行操作。\n";
    $prompt .= "支持的操作及返回格式：\n";
    $prompt .= "1. 修改单封邮件（基于ID）：返回JSON {\"action\":\"update_mail\", \"id\":邮件ID, \"new_content\":\"完整新内容\"}\n";
    $prompt .= "2. 批量修改邮件内容（基于关键词和时间范围）：返回JSON {\"action\":\"update_by_content\", \"search\":\"要查找的字符串\", \"replace\":\"替换为的字符串\", \"time_range\":\"today|yesterday|week\"}\n";
    $prompt .= "   - time_range 可选，不提供则默认所有时间。\n";
    $prompt .= "   - 例如“把所有包含6的邮件中的6改成8” -> {\"action\":\"update_by_content\", \"search\":\"6\", \"replace\":\"8\"}\n";
    $prompt .= "   - 例如“把今天收到的邮件中的6改成8” -> {\"action\":\"update_by_content\", \"search\":\"6\", \"replace\":\"8\", \"time_range\":\"today\"}\n";
    $prompt .= "3. 如果用户只是询问或要求显示内容，直接回复文本，不要返回JSON。\n";
    $prompt .= "只返回一个JSON对象（如果适用）或纯文本。\n";

    $deepseekResp = callDeepSeek($prompt);
    if (isset($deepseekResp['error'])) {
        $aiReply = "AI服务暂时不可用，请稍后再试。";
    } else {
        $reply = trim($deepseekResp['reply']);
        // 提取最后一个 JSON 对象
        $json = null;
        $lastPos = strrpos($reply, '{');
        if ($lastPos !== false) {
            $possibleJson = substr($reply, $lastPos);
            $endPos = strpos($possibleJson, '}');
            if ($endPos !== false) {
                $jsonStr = substr($possibleJson, 0, $endPos + 1);
                $json = json_decode($jsonStr, true);
            }
        }
        if ($json && isset($json['action'])) {
            if ($json['action'] === 'update_mail' && isset($json['id']) && isset($json['new_content'])) {
                $id = intval($json['id']);
                $newContent = trim($json['new_content']);
                $stmt = $db->prepare("SELECT id FROM messages WHERE id = ? AND to_username = ?");
                $stmt->execute([$id, $username]);
                if ($stmt->fetch()) {
                    $stmt = $db->prepare("UPDATE messages SET content = ? WHERE id = ?");
                    $stmt->execute([$newContent, $id]);
                    $aiReply = "已成功修改邮件ID {$id} 的内容为：{$newContent}";
                } else {
                    $aiReply = "无权修改该邮件，请确认邮件ID正确。";
                }
            } elseif ($json['action'] === 'update_by_content') {
                $search = $json['search'] ?? '';
                $replace = $json['replace'] ?? '';
                if ($search === '' || $replace === '') {
                    $aiReply = "请提供要查找的字符串和替换的字符串。";
                } else {
                    // 构建时间条件
                    $timeCondition = "";
                    if (isset($json['time_range'])) {
                        switch ($json['time_range']) {
                            case 'today':
                                $timeCondition = " AND created_at >= " . strtotime('today');
                                break;
                            case 'yesterday':
                                $timeCondition = " AND created_at >= " . strtotime('yesterday') . " AND created_at < " . strtotime('today');
                                break;
                            case 'week':
                                $timeCondition = " AND created_at >= " . strtotime('-7 days');
                                break;
                        }
                    }
                    // 查询符合条件的邮件
                    $stmt = $db->prepare("SELECT id, content FROM messages WHERE to_username = ? AND content LIKE ? $timeCondition");
                    $like = '%' . $search . '%';
                    $stmt->execute([$username, $like]);
                    $matched = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $count = count($matched);
                    if ($count == 0) {
                        $aiReply = "没有找到符合条件的邮件。";
                    } else {
                        $updatedCount = 0;
                        foreach ($matched as $mail) {
                            $newContent = str_replace($search, $replace, $mail['content']);
                            $upd = $db->prepare("UPDATE messages SET content = ? WHERE id = ?");
                            $upd->execute([$newContent, $mail['id']]);
                            $updatedCount++;
                        }
                        $aiReply = "已成功将 {$updatedCount} 封邮件中的“{$search}”替换为“{$replace}”。";
                    }
                }
            } else {
                $aiReply = "无法识别的操作。";
            }
        } else {
            $aiReply = $reply;
        }
    }

    // 保存 AI 回复到对话历史
    $stmt = $db->prepare("INSERT INTO ai_chat_history (username, role, content, created_at) VALUES (?, 'assistant', ?, ?)");
    $stmt->execute([$username, $aiReply, time()]);

    echo json_encode(['success' => true, 'reply' => $aiReply]);
    exit;
}

// 获取公告列表
if ($action === 'announcements') {
    $stmt = $db->query("SELECT id, title, content, created_at FROM announcements ORDER BY created_at DESC");
    $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'announcements' => $list]);
    exit;
}

// 获取单条公告
if ($action === 'announcement') {
    $id = intval($_GET['id'] ?? 0);
    $stmt = $db->prepare("SELECT title, content, created_at FROM announcements WHERE id = ?");
    $stmt->execute([$id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($item) {
        echo json_encode(['success' => true, 'announcement' => $item]);
    } else {
        echo json_encode(['success' => false, 'error' => '公告不存在']);
    }
    exit;
}

// 退出登录
if ($action === 'logout') {
    session_destroy();
    echo json_encode(['success' => true]);
    exit;
}

// 长轮询（可选，保留）
if ($action === 'poll_inbox') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $lastCount = intval($_GET['last_count'] ?? 0);
    $timeout = 15;
    $start = time();
    while (time() - $start < $timeout) {
        $stmt = $db->prepare("SELECT COUNT(*) FROM messages WHERE to_username = ?");
        $stmt->execute([$_SESSION['user']]);
        $newCount = $stmt->fetchColumn();
        if ($newCount > $lastCount) {
            echo json_encode(['success' => true, 'new_count' => $newCount]);
            exit;
        }
        usleep(500000);
    }
    echo json_encode(['success' => true, 'new_count' => $lastCount]);
    exit;
}

// 删除消息（收件箱或发件箱）
if ($action === 'delete_message') {
    if (!isset($_SESSION['user'])) {
        echo json_encode(['success' => false, 'error' => '未登录']);
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    if (!$id) {
        echo json_encode(['success' => false, 'error' => '消息ID无效']);
        exit;
    }
    $username = $_SESSION['user'];
    $db = DB::get();
    $stmt = $db->prepare("DELETE FROM messages WHERE id = ? AND (to_username = ? OR from_username = ?)");
    $stmt->execute([$id, $username, $username]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => '删除成功']);
    } else {
        echo json_encode(['success' => false, 'error' => '消息不存在或无权删除']);
    }
    exit;
}

// 未匹配的操作
echo json_encode(['success' => false, 'error' => '无效请求']);
?>