<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}
$username = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>发新消息 · WWP</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: radial-gradient(circle at 20% 30%, #0a0f2a, #03050b);
            min-height: 100vh;
            font-family: 'Inter', sans-serif;
        }
        .compose-container {
            max-width: 600px;
            margin: 40px auto;
            padding: 32px;
            background: rgba(10, 20, 40, 0.75);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(0, 255, 255, 0.3);
            border-radius: 32px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #0ff;
            font-weight: 600;
        }
        input, textarea {
            width: 100%;
            padding: 12px 16px;
            background: rgba(0, 0, 0, 0.6);
            border: 1px solid #0ff;
            color: #0ff;
            border-radius: 28px;
            outline: none;
            font-size: 1rem;
        }
        textarea {
            border-radius: 20px;
            resize: vertical;
        }
        button {
            margin-top: 8px;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #0ff;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .error-message {
            color: #ff6680;
            margin-top: 12px;
        }
        .success-message {
            color: #0f0;
            margin-top: 12px;
        }
        @media (max-width: 768px) {
            .compose-container {
                margin: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
<div class="compose-container">
    <h1 style="margin-bottom: 24px;">📝 发新消息</h1>
    <div class="form-group">
        <label>收件人地址 (格式: 用户名#域名)</label>
        <input type="text" id="to" placeholder="例如: test#ai2000.cc" autocomplete="off">
    </div>
    <div class="form-group">
        <label>主题</label>
        <input type="text" id="subject" placeholder="主题" autocomplete="off">
    </div>
    <div class="form-group">
        <label>内容</label>
        <textarea id="content" rows="6" placeholder="写下你的消息..."></textarea>
    </div>
    <button class="btn-neon btn-primary" id="sendBtn">发送</button>
    <div id="result"></div>
    <a href="dashboard.php" class="back-link">← 返回个人中心</a>
</div>

<script>
    const API_BASE = 'api_demo.php';

    document.getElementById('sendBtn').onclick = async () => {
        const to = document.getElementById('to').value.trim();
        const subject = document.getElementById('subject').value.trim();
        const content = document.getElementById('content').value.trim();

        if (!to || !content) {
            document.getElementById('result').innerHTML = '<div class="error-message">❌ 收件人地址和内容不能为空</div>';
            return;
        }
        // 简单验证地址格式（必须包含 #）
        if (to.indexOf('#') === -1) {
            document.getElementById('result').innerHTML = '<div class="error-message">❌ 收件人地址格式错误，应为 用户名#域名（例如 test#ai2000.cc）</div>';
            return;
        }

        const formData = new FormData();
        formData.append('action', 'send_new');
        formData.append('to', to);
        formData.append('subject', subject);
        formData.append('content', content);

        try {
            const res = await fetch(API_BASE, { method: 'POST', body: formData });
            const data = await res.json();
            if (data.success) {
                document.getElementById('result').innerHTML = '<div class="success-message">✅ 消息已发送！正在返回个人中心...</div>';
                setTimeout(() => {
                    window.location.href = 'dashboard.php';
                }, 1500);
            } else {
                document.getElementById('result').innerHTML = `<div class="error-message">❌ 发送失败：${escapeHtml(data.error)}</div>`;
            }
        } catch (err) {
            document.getElementById('result').innerHTML = `<div class="error-message">❌ 网络错误：${escapeHtml(err.message)}</div>`;
        }
    };

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }
</script>
</body>
</html>