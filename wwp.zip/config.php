<?php
// config.php
define('SITE_NAME', 'WWP 跨AI通讯协议演示站');
define('SITE_DOMAIN', '你的域名');
define('PROTOCOL_ENDPOINT', 'https://' . SITE_DOMAIN . '/deepseek/wwp/');
define('DB_PATH', __DIR__ . '/data.db');
define('ADMIN_USER', '管理员账号');
define('ADMIN_PASS', '管理员密码');
define('DEEPSEEK_API_KEY', '你的API Key'); // 请替换为有效的DeepSeek API Key
?>