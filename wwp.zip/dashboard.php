<?php
// dashboard.php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}
$username = $_SESSION['user'];
require_once __DIR__ . '/db.php';
$db = DB::get();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>个人中心 · WWP</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* 基础布局样式保持不变 */
        .dashboard-container {
            display: flex;
            flex-wrap: wrap;
            gap: 24px;
            margin-top: 20px;
        }
        .mail-panel, .sent-panel {
            flex: 1;
            min-width: 220px;
            background: var(--glass-bg);
            backdrop-filter: blur(12px);
            border-radius: 32px;
            border: 1px solid var(--border-glow);
            padding: 20px;
            overflow-y: auto;
            max-height: 80vh;
        }
        .chat-panel {
            flex: 2;
            min-width: 300px;
            background: var(--glass-bg);
            backdrop-filter: blur(12px);
            border-radius: 32px;
            border: 1px solid var(--border-glow);
            display: flex;
            flex-direction: column;
            height: 80vh;
        }
        /* 邮件条目使用 flex 布局，容纳删除按钮 */
        .mail-item, .sent-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid var(--border-glow);
            cursor: pointer;
            transition: 0.2s;
        }
        .mail-item:hover, .sent-item:hover {
            background: rgba(0,255,255,0.1);
        }
        .mail-item.unread {
            background: rgba(0,255,255,0.05);
            border-left: 3px solid var(--neon-cyan);
        }
        .mail-content {
            flex: 1;
            overflow: hidden;
        }
        .mail-subject {
            font-weight: 600;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .mail-preview {
            font-size: 0.8rem;
            opacity: 0.7;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .mail-actions {
            margin-left: 12px;
        }
        .delete-mail-btn, .delete-sent-btn {
            background: rgba(255, 80, 80, 0.2);
            border: 1px solid #ff4d4d;
            color: #ff4d4d;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            cursor: pointer;
            transition: 0.2s;
        }
        .delete-mail-btn:hover, .delete-sent-btn:hover {
            background: #ff4d4d;
            color: #fff;
            box-shadow: 0 0 8px #ff4d4d;
        }
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .message {
            display: flex;
            flex-direction: column;
        }
        .message .bubble {
            max-width: 75%;
            padding: 10px 16px;
            border-radius: 20px;
            background: rgba(0,0,0,0.5);
            border: 1px solid var(--neon-cyan);
            align-self: flex-start;
        }
        .message.user {
            align-items: flex-end;
        }
        .message.user .bubble {
            background: var(--neon-cyan);
            color: #010515;
        }
        .chat-input-area {
            padding: 16px;
            border-top: 1px solid var(--border-glow);
            display: flex;
            gap: 12px;
        }
        .chat-input-area input {
            flex: 1;
        }
        .reply-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(8px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            visibility: hidden;
            opacity: 0;
            transition: 0.2s;
        }
        .reply-modal.show {
            visibility: visible;
            opacity: 1;
        }
        .reply-modal-content {
            background: #0a1022;
            border: 1px solid var(--neon-cyan);
            border-radius: 32px;
            max-width: 500px;
            width: 90%;
            padding: 24px;
            color: #0ff;
        }
        .pagination {
            margin-top: 16px;
            display: flex;
            justify-content: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        .page-btn {
            background: rgba(0,255,255,0.1);
            border: 1px solid #0ff;
            color: #0ff;
            padding: 4px 10px;
            border-radius: 20px;
            cursor: pointer;
        }
        .page-btn.active {
            background: #0ff;
            color: #010515;
        }
        @media (max-width: 768px) {
            .dashboard-container { flex-direction: column; }
            .mail-panel, .sent-panel, .chat-panel { max-height: 50vh; min-width: auto; }
            .mail-subject, .mail-preview { white-space: normal; }
        }
    </style>
</head>
<body>
<div class="container">
    <header>
        <div class="logo">WWP<span>:// <?= htmlspecialchars($username . '#ai0539.cc') ?></span></div>
        <div class="nav-buttons">
            <span class="btn-neon" style="cursor:default;">📧 <?= htmlspecialchars($username . '#ai0539.cc') ?></span>
            <button class="btn-neon" id="logoutBtn">退出</button>
        </div>
    </header>
    <div class="dashboard-container">
        <div class="mail-panel">
            <h3>📬 收件箱</h3>
            <div id="mailList">加载中...</div>
            <div id="mailPagination" class="pagination"></div>
            <div id="newMsgHint" style="margin-top: 10px; text-align: center; display: none;">
                <span class="btn-neon" id="refreshInboxBtn" style="padding: 4px 12px;">✨ 有新消息，点击刷新</span>
            </div>
        </div>
        <div class="chat-panel">
            <div class="chat-header" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-bottom: 1px solid var(--border-glow);">
                <span>💬 AI 助手</span>
                <button id="clearChatHistoryBtn" class="btn-neon" style="padding: 4px 12px; font-size: 0.7rem;">🗑️ 清空聊天记录</button>
            </div>
            <div class="chat-messages" id="chatMessages"></div>
            <div class="chat-input-area">
                <input type="text" id="chatInput" placeholder="输入消息..." autocomplete="off">
                <button class="btn-neon" id="sendBtn">发送</button>
            </div>
        </div>
        <div class="sent-panel">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                <h3 style="margin:0;">📤 发件箱</h3>
                <a href="compose.php" class="btn-neon" style="padding: 4px 12px; font-size: 0.8rem; text-decoration: none;">➕ 发新消息</a>
            </div>
            <div id="sentList">加载中...</div>
            <div id="sentPagination" class="pagination"></div>
        </div>
    </div>
</div>

<div id="replyModal" class="reply-modal">
    <div class="reply-modal-content">
        <h3>✍️ 回复消息</h3>
        <textarea id="replyContent" rows="4" style="width:100%; background:#021a2a; border:1px solid #0ff; color:#0ff; padding:8px; border-radius:16px;"></textarea>
        <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:16px;">
            <button class="btn-neon" id="cancelReplyBtn">取消</button>
            <button class="btn-neon btn-primary" id="confirmReplyBtn">发送回复</button>
        </div>
    </div>
</div>

<script>
    const API_BASE = 'api_demo.php';
    let currentUser = <?= json_encode($username) ?>;
    let currentReplyParentId = null;
    let currentReplyToUser = null;
    let inboxPage = 1;
    let inboxTotal = 0;
    let sentPage = 1;
    let sentTotal = 0;
    const PER_PAGE = 10;
    let pollingInterval = null;

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, m => m === '&' ? '&amp;' : m === '<' ? '&lt;' : m === '>' ? '&gt;' : m);
    }

    // 删除消息的通用函数
    async function deleteMessage(id) {
        const formData = new FormData();
        formData.append('action', 'delete_message');
        formData.append('id', id);
        const res = await fetch(API_BASE, { method: 'POST', body: formData });
        const data = await res.json();
        if (!data.success) {
            alert('删除失败：' + data.error);
        }
        return data.success;
    }

    // 渲染收件箱（带删除按钮）
    function renderMailList(messages) {
        const container = document.getElementById('mailList');
        if (!messages || messages.length === 0) {
            container.innerHTML = '<div style="padding:12px">暂无邮件</div>';
            return;
        }
        container.innerHTML = messages.map(msg => `
            <div class="mail-item ${msg.is_read ? '' : 'unread'}" data-id="${msg.id}" data-from="${escapeHtml(msg.from_username)}">
                <div class="mail-content">
                    <div class="mail-subject">${escapeHtml(msg.subject || '(无标题)')}</div>
                    <div class="mail-preview">来自 ${escapeHtml(msg.from_username)} · ${new Date(msg.created_at*1000).toLocaleString()}</div>
                </div>
                <div class="mail-actions">
                    <button class="delete-mail-btn" data-id="${msg.id}">🗑️ 删除</button>
                </div>
            </div>
        `).join('');
        // 绑定查看邮件事件（点击内容区域）
        document.querySelectorAll('.mail-item').forEach(el => {
            const contentDiv = el.querySelector('.mail-content');
            const deleteBtn = el.querySelector('.delete-mail-btn');
            contentDiv.addEventListener('click', (e) => {
                e.stopPropagation();
                showMail(el.dataset.id);
            });
            deleteBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const id = deleteBtn.dataset.id;
                if (confirm('确定要删除这封邮件吗？')) {
                    const success = await deleteMessage(id);
                    if (success) {
                        loadInbox(inboxPage);
                    }
                }
            });
        });
    }

    // 渲染发件箱（带删除按钮）
    function renderSentList(messages) {
        const container = document.getElementById('sentList');
        if (!messages || messages.length === 0) {
            container.innerHTML = '<div style="padding:12px">暂无发件</div>';
            return;
        }
        container.innerHTML = messages.map(msg => `
            <div class="sent-item" data-id="${msg.id}">
                <div class="mail-content">
                    <div class="mail-subject">${escapeHtml(msg.subject || '(无标题)')}</div>
                    <div class="mail-preview">发给 ${escapeHtml(msg.to_username)} · ${new Date(msg.created_at*1000).toLocaleString()}</div>
                </div>
                <div class="mail-actions">
                    <button class="delete-sent-btn" data-id="${msg.id}">🗑️ 删除</button>
                </div>
            </div>
        `).join('');
        document.querySelectorAll('.sent-item').forEach(el => {
            const contentDiv = el.querySelector('.mail-content');
            const deleteBtn = el.querySelector('.delete-sent-btn');
            contentDiv.addEventListener('click', (e) => {
                e.stopPropagation();
                showSentMail(el.dataset.id);
            });
            deleteBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const id = deleteBtn.dataset.id;
                if (confirm('确定要删除这封已发送的邮件吗？')) {
                    const success = await deleteMessage(id);
                    if (success) {
                        loadSent(sentPage);
                    }
                }
            });
        });
    }

    function renderPagination(containerId, currentPage, totalPages, loadFunc) {
        const container = document.getElementById(containerId);
        if (!container) return;
        if (totalPages <= 1) {
            container.innerHTML = '';
            return;
        }
        let html = '';
        for (let i = 1; i <= totalPages; i++) {
            html += `<button class="page-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</button>`;
        }
        container.innerHTML = html;
        container.querySelectorAll('.page-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const page = parseInt(btn.dataset.page);
                loadFunc(page);
            });
        });
    }

    async function loadInbox(page = 1) {
        try {
            const res = await fetch(`${API_BASE}?action=get_messages&page=${page}`);
            const data = await res.json();
            if (data.success) {
                renderMailList(data.messages);
                inboxTotal = data.total;
                inboxPage = data.page;
                renderPagination('mailPagination', inboxPage, Math.ceil(inboxTotal / PER_PAGE), loadInbox);
                return data.total;
            } else {
                document.getElementById('mailList').innerHTML = '<div>加载失败</div>';
                return 0;
            }
        } catch (err) {
            console.error('收件箱加载失败', err);
            document.getElementById('mailList').innerHTML = '<div>加载失败</div>';
            return 0;
        }
    }

    async function loadSent(page = 1) {
        try {
            const res = await fetch(`${API_BASE}?action=get_sent&page=${page}`);
            const data = await res.json();
            if (data.success) {
                renderSentList(data.messages);
                sentTotal = data.total;
                sentPage = data.page;
                renderPagination('sentPagination', sentPage, Math.ceil(sentTotal / PER_PAGE), loadSent);
            } else {
                document.getElementById('sentList').innerHTML = '<div>加载失败</div>';
            }
        } catch (err) {
            console.error('发件箱加载失败', err);
            document.getElementById('sentList').innerHTML = '<div>加载失败</div>';
        }
    }

    async function showMail(id) {
        const res = await fetch(`${API_BASE}?action=get_message&id=${id}`);
        const data = await res.json();
        if (data.success) {
            const msg = data.message;
            const chatDiv = document.getElementById('chatMessages');
            chatDiv.innerHTML = '';
            appendMessage('ai', `📧 来自 ${msg.from_username}：\n${msg.content}`, false);
            const repliesRes = await fetch(`${API_BASE}?action=get_replies&parent_id=${id}`);
            const repliesData = await repliesRes.json();
            if (repliesData.success && repliesData.replies.length) {
                for (let reply of repliesData.replies) {
                    const role = reply.from_username === currentUser ? 'user' : 'ai';
                    appendMessage(role, reply.content, false);
                }
            }
            const replyBtnContainer = document.createElement('div');
            replyBtnContainer.className = 'message';
            replyBtnContainer.style.marginTop = '16px';
            replyBtnContainer.innerHTML = `<button class="reply-btn" data-id="${id}" data-to="${escapeHtml(msg.from_username)}" style="background:none; border:1px solid #0ff; color:#0ff; padding:6px 16px; border-radius:20px; cursor:pointer;">回复此消息</button>`;
            chatDiv.appendChild(replyBtnContainer);
            replyBtnContainer.querySelector('.reply-btn').addEventListener('click', () => {
                openReplyModal(id, msg.from_username);
            });
        }
        loadInbox(inboxPage);
    }

    async function showSentMail(id) {
        const res = await fetch(`${API_BASE}?action=get_message&id=${id}`);
        const data = await res.json();
        if (data.success) {
            const msg = data.message;
            const chatDiv = document.getElementById('chatMessages');
            chatDiv.innerHTML = '';
            appendMessage('user', `📤 发给 ${msg.from_username}：\n${msg.content}`, false);
        }
    }

    async function sendMessage() {
        const input = document.getElementById('chatInput');
        const text = input.value.trim();
        if (!text) return;
        appendMessage('user', text);
        input.value = '';
        const thinkingDiv = appendMessage('ai', '🤔 思考中...', false);
        try {
            const formData = new FormData();
            formData.append('action', 'ai_chat');
            formData.append('message', text);
            const res = await fetch(API_BASE, { method: 'POST', body: formData });
            const data = await res.json();
            if (data.success) {
                thinkingDiv.innerHTML = `<div class="bubble">${escapeHtml(data.reply)}</div>`;
                loadInbox(inboxPage);
                loadSent(sentPage);
            } else {
                thinkingDiv.innerHTML = `<div class="bubble">❌ 错误：${escapeHtml(data.error)}</div>`;
            }
        } catch (err) {
            thinkingDiv.innerHTML = `<div class="bubble">网络错误</div>`;
        }
        const chatDiv = document.getElementById('chatMessages');
        chatDiv.scrollTop = chatDiv.scrollHeight;
    }

    function appendMessage(role, text, autoScroll = true) {
        const div = document.createElement('div');
        div.className = `message ${role}`;
        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        bubble.innerText = text;
        div.appendChild(bubble);
        const chatDiv = document.getElementById('chatMessages');
        chatDiv.appendChild(div);
        if (autoScroll) chatDiv.scrollTop = chatDiv.scrollHeight;
        return div;
    }

    function openReplyModal(parentId, toUser) {
        currentReplyParentId = parentId;
        currentReplyToUser = toUser;
        document.getElementById('replyModal').classList.add('show');
        document.getElementById('replyContent').value = '';
    }

    async function sendReply() {
        const content = document.getElementById('replyContent').value.trim();
        if (!content) {
            alert('请输入回复内容');
            return;
        }
        const formData = new FormData();
        formData.append('action', 'send_reply');
        formData.append('parent_id', currentReplyParentId);
        formData.append('to', currentReplyToUser);
        formData.append('content', content);
        const res = await fetch(API_BASE, { method: 'POST', body: formData });
        const data = await res.json();
        if (data.success) {
            alert('回复已发送');
            document.getElementById('replyModal').classList.remove('show');
            loadInbox(inboxPage);
            loadSent(sentPage);
            const chatDiv = document.getElementById('chatMessages');
            const maybeReplyBtn = chatDiv.querySelector('.reply-btn');
            if (maybeReplyBtn) {
                const parentId = maybeReplyBtn.closest('.message').querySelector('.reply-btn')?.dataset.id;
                if (parentId) showMail(parentId);
            }
        } else {
            alert('发送失败：' + data.error);
        }
    }

    function startPolling() {
        if (pollingInterval) clearInterval(pollingInterval);
        pollingInterval = setInterval(async () => {
            if (!document.hidden) {
                const newTotal = await loadInbox(inboxPage);
                if (newTotal > inboxTotal) {
                    inboxTotal = newTotal;
                    if (inboxPage !== 1) {
                        document.getElementById('newMsgHint').style.display = 'block';
                    }
                }
            }
        }, 30000);
    }

    // 清空聊天记录函数
    async function clearChatHistory() {
        if (!confirm('确定要清空所有AI聊天记录吗？此操作不可恢复。')) return;
        const formData = new FormData();
        formData.append('action', 'clear_chat_history');
        const res = await fetch(API_BASE, { method: 'POST', body: formData });
        const data = await res.json();
        if (data.success) {
            const chatDiv = document.getElementById('chatMessages');
            chatDiv.innerHTML = '';
            appendMessage('ai', '聊天记录已清空。你好！我是你的AI助手，有什么可以帮你的？', false);
        } else {
            alert('清空失败：' + data.error);
        }
    }

    // 加载AI聊天历史
    async function loadChatHistory() {
        const res = await fetch(`${API_BASE}?action=get_ai_history`);
        const data = await res.json();
        if (data.success) {
            const chatDiv = document.getElementById('chatMessages');
            chatDiv.innerHTML = '';
            data.history.forEach(msg => {
                const role = msg.role === 'user' ? 'user' : 'ai';
                appendMessage(role, msg.content, false);
            });
            if (data.history.length === 0) {
                appendMessage('ai', '你好！我是你的AI助手，可以帮你整理邮件、修改内容等。');
            }
        }
    }

    // 绑定事件
    document.getElementById('refreshInboxBtn')?.addEventListener('click', () => {
        loadInbox(1);
        document.getElementById('newMsgHint').style.display = 'none';
    });
    document.getElementById('clearChatHistoryBtn')?.addEventListener('click', clearChatHistory);
    document.getElementById('sendBtn').onclick = sendMessage;
    document.getElementById('chatInput').addEventListener('keypress', e => { if (e.key === 'Enter') sendMessage(); });
    document.getElementById('logoutBtn').onclick = async () => {
        await fetch(API_BASE + '?action=logout');
        window.location.href = 'index.php';
    };
    document.getElementById('cancelReplyBtn').onclick = () => document.getElementById('replyModal').classList.remove('show');
    document.getElementById('confirmReplyBtn').onclick = sendReply;

    // 页面初始化
    window.addEventListener('DOMContentLoaded', async () => {
        await Promise.all([loadInbox(1), loadSent(1)]);
        startPolling();
        loadChatHistory();
    });
</script>
</body>
</html>