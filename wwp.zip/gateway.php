<?php
// gateway.php - 处理跨站消息（签名验证、存储、AI自动回复）
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

$from = $input['from'];
$to = $input['to'];
$content = $input['content'];
$timestamp = $input['timestamp'];
$signature = base64_decode($input['signature']);

// 验证签名
$parts = explode('#', $from);
if (count($parts) != 2) {
    echo json_encode(['error' => 'Invalid from address']);
    exit;
}
$fromDomain = $parts[1];
$pubKeyUrl = "https://$fromDomain/deepseek/wwp/public-key.pem";
$pubKeyPem = @file_get_contents($pubKeyUrl);
if (!$pubKeyPem) {
    echo json_encode(['error' => "Cannot download public key from $pubKeyUrl"]);
    exit;
}
$pubKey = openssl_pkey_get_public($pubKeyPem);
if (!$pubKey) {
    echo json_encode(['error' => 'Invalid public key']);
    exit;
}
$data = $from . $to . $content . $timestamp;
$hash = hash('sha256', $data, true);
$valid = openssl_verify($hash, $signature, $pubKey, OPENSSL_ALGO_SHA256);
if ($valid !== 1) {
    echo json_encode(['error' => 'Signature verification failed']);
    exit;
}

// 存储消息到收件箱（目标用户名从 to 中提取）
$db = DB::get();
$toUsername = explode('#', $to)[0];
$fromFull = $from;  // 保存完整的发件人地址
$stmt = $db->prepare("INSERT INTO messages (to_username, from_username, subject, content, created_at) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([$toUsername, $fromFull, '跨站消息', $content, time()]);

// AI自动回复（若发件人不是机器人）
if (strpos($from, 'ai-bot#') === false && strpos($from, 'reply-bot#') === false) {
    $aiReply = aiGenerateReply($content);
    if ($aiReply) {
        // 构造回复消息并发送回原发件人
        $replyFrom = 'ai-bot#' . SITE_DOMAIN;
        $replyTo = $from;
        $replyTimestamp = time();
        $replyData = $replyFrom . $replyTo . $aiReply . $replyTimestamp;
        $replyHash = hash('sha256', $replyData, true);
        $privateKey = openssl_pkey_get_private('file://' . __DIR__ . '/private-key.pem');
        if ($privateKey) {
            openssl_sign($replyHash, $replySignature, $privateKey, OPENSSL_ALGO_SHA256);
            $replyPayload = [
                'from' => $replyFrom,
                'to' => $replyTo,
                'content' => $aiReply,
                'timestamp' => $replyTimestamp,
                'signature' => base64_encode($replySignature)
            ];
            $targetDomain = explode('#', $replyTo)[1];
            $targetUrl = "https://$targetDomain/deepseek/wwp/";
            $ch = curl_init($targetUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($replyPayload));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_exec($ch);
            curl_close($ch);
        }
    }
}

echo json_encode(['success' => true, 'message' => 'Message processed']);
exit;

function aiGenerateReply($message) {
    $apiKey = DEEPSEEK_API_KEY;
    $url = 'https://api.deepseek.com/v1/chat/completions';
    $payload = [
        'model' => 'deepseek-chat',
        'messages' => [
            ['role' => 'system', 'content' => '你是一个友好的AI助手，收到一条消息，请根据内容生成一句简短、自然的回复。回复不要超过50字。'],
            ['role' => 'user', 'content' => $message]
        ],
        'max_tokens' => 100,
        'temperature' => 0.8
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $resp = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($resp, true);
    return trim($data['choices'][0]['message']['content'] ?? '');
}
?>