// demo.js
// 加载验证码
async function loadCaptcha() {
    const res = await fetch('api_demo.php?action=captcha');
    const data = await res.json();
    document.getElementById('captchaQuestion').innerText = data.question;
    document.getElementById('regCaptchaQuestion').innerText = data.question;
    window.captchaResult = data.result; // 实际不存储，后端验证
}
loadCaptcha();

// 切换登录/注册
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const tab = btn.dataset.tab;
        document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
        document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
    });
});

// 登录
document.getElementById('doLogin').onclick = async () => {
    const username = document.getElementById('login_user').value.trim();
    const password = document.getElementById('login_pass').value;
    const captcha = document.getElementById('login_captcha').value.trim();
    const formData = new FormData();
    formData.append('action', 'login');
    formData.append('username', username);
    formData.append('password', password);
    formData.append('captcha', captcha);
    const res = await fetch('api_demo.php', { method: 'POST', body: formData });
    const data = await res.json();
    if (data.success) {
        window.location.href = 'dashboard.php';
    } else {
        document.getElementById('loginMsg').innerText = data.error;
        loadCaptcha();
    }
};

// 注册
document.getElementById('doRegister').onclick = async () => {
    const username = document.getElementById('reg_user').value.trim();
    const password = document.getElementById('reg_pass').value;
    const captcha = document.getElementById('reg_captcha').value.trim();
    const formData = new FormData();
    formData.append('action', 'register');
    formData.append('username', username);
    formData.append('password', password);
    formData.append('captcha', captcha);
    const res = await fetch('api_demo.php', { method: 'POST', body: formData });
    const data = await res.json();
    if (data.success) {
        alert('注册成功，请登录');
        document.querySelector('.tab-btn[data-tab="login"]').click();
    } else {
        document.getElementById('regMsg').innerText = data.error;
        loadCaptcha();
    }
};

// 加载公告
async function loadAnnouncements() {
    const res = await fetch('api_demo.php?action=announcements');
    const data = await res.json();
    if (data.success) {
        const container = document.getElementById('announcementsList');
        container.innerHTML = data.announcements.map(a => `
            <div class="announcement-item" data-id="${a.id}">
                <div class="announcement-title">${escapeHtml(a.title)}</div>
                <div class="announcement-date">${new Date(a.created_at*1000).toLocaleString()}</div>
            </div>
        `).join('');
        document.querySelectorAll('.announcement-item').forEach(el => {
            el.addEventListener('click', () => showAnnouncement(el.dataset.id));
        });
    }
}
async function showAnnouncement(id) {
    const res = await fetch(`api_demo.php?action=announcement&id=${id}`);
    const data = await res.json();
    if (data.success) {
        alert(`【${data.announcement.title}】\n\n${data.announcement.content}`);
    }
}
loadAnnouncements();

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, m => m === '&' ? '&amp;' : m === '<' ? '&lt;' : m === '>' ? '&gt;' : m);
}

// 模态框
const modal = document.getElementById('protocolModal');
document.getElementById('showProtocolBtn').onclick = () => modal.classList.add('show');
document.getElementById('closeModalBtn').onclick = () => modal.classList.remove('show');
window.onclick = (e) => { if (e.target === modal) modal.classList.remove('show'); };