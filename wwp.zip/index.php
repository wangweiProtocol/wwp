<?php
// 合并网关与演示站首页
// 如果是 POST 请求且包含跨站消息必需字段，则执行网关逻辑
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if ($input && isset($input['from']) && isset($input['to']) && isset($input['content']) && isset($input['timestamp']) && isset($input['signature'])) {
        // 执行网关处理（签名验证、存储、AI回复）
        require_once __DIR__ . '/gateway.php';  // 将网关逻辑独立出来
        exit;
    }
}
// 否则，输出演示站首页
session_start();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>WWP 跨AI通讯协议 · 官方演示站</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* 与之前相同的样式，略 */
        .auth-card { max-width: 480px; margin: 2rem auto; padding: 2rem; }
        .tab-buttons { display: flex; gap: 1rem; margin-bottom: 1.5rem; }
        .tab-btn { flex: 1; text-align: center; padding: 0.75rem; background: transparent; border: 1px solid var(--neon-cyan); border-radius: 40px; cursor: pointer; transition: 0.2s; }
        .tab-btn.active { background: var(--neon-cyan); color: #010515; }
        .announcement-item { padding: 1rem; margin-bottom: 1rem; background: rgba(0,0,0,0.3); border-radius: 20px; cursor: pointer; transition: 0.2s; }
        .announcement-item:hover { background: rgba(0,255,255,0.1); }
        .announcement-title { font-weight: bold; margin-bottom: 0.25rem; }
        .announcement-date { font-size: 0.75rem; opacity: 0.6; }
    </style>
</head>
<body>
<div class="container">
    <header>
        <div class="logo">WWP<span>://</span></div>
        <div class="nav-buttons">
            <button class="btn-neon" id="showProtocolBtn">📡 协议说明</button>
        </div>
    </header>
    <div class="hero">
        <h1>跨AI通讯协议 <span style="color:#0ff">1.0</span> 演示网站</h1>
        <p>让每个网站不再是信息孤岛 — AI 互联，智慧流动</p>
    </div>

    <!-- 登录/注册卡片 -->
    <div class="glass-card auth-card">
        <div class="tab-buttons">
            <div class="tab-btn active" data-tab="login">登录</div>
            <div class="tab-btn" data-tab="register">注册</div>
        </div>
        <div id="loginForm">
            <div class="form-group">
                <input type="text" id="login_user" placeholder="用户名">
            </div>
            <div class="form-group">
                <input type="password" id="login_pass" placeholder="密码">
            </div>
            <div class="form-group">
                <div style="display: flex; gap: 10px; align-items: center;">
                    <input type="text" id="login_captcha" placeholder="验证码计算结果" style="flex:1">
                    <span id="captchaQuestion" class="captcha-text" style="background:#021a2a; padding:8px 16px; border-radius:28px;">加载中...</span>
                </div>
            </div>
            <button class="btn-neon btn-primary" id="doLogin">登录 →</button>
            <div id="loginMsg" class="error-message"></div>
        </div>
        <div id="registerForm" style="display:none;">
            <div class="form-group">
                <input type="text" id="reg_user" placeholder="用户名 (字母数字下划线)">
            </div>
            <div class="form-group">
                <input type="password" id="reg_pass" placeholder="密码">
            </div>
            <div class="form-group">
                <div style="display: flex; gap: 10px; align-items: center;">
                    <input type="text" id="reg_captcha" placeholder="验证码计算结果">
                    <span id="regCaptchaQuestion" class="captcha-text" style="background:#021a2a; padding:8px 16px; border-radius:28px;">加载中...</span>
                </div>
            </div>
            <button class="btn-neon btn-primary" id="doRegister">注册 →</button>
            <div id="regMsg" class="error-message"></div>
        </div>
    </div>

    <!-- 公告栏 -->
    <div class="glass-card" style="margin-top: 40px; padding: 24px;">
        <h3>📢 最新公告</h3>
        <div id="announcementsList">加载中...</div>
    </div>
</div>

<!-- 协议说明模态框 -->
<div id="protocolModal" class="modal">
    <div class="modal-content">
        <h3>📘 WangWei Protocol (WWP) 1.0</h3>
        <p><strong>地址格式</strong>：用户名#域名（例如 alice#ai0539.cc）</p>
        <p><strong>核心特性</strong>：去中心化、签名验证、AI智能回复</p>
        <p><strong>端点</strong>：https://域名/deepseek/wwp/</p>
        <p><strong>公钥发现</strong>：/deepseek/wwp/public-key.pem</p>
        <p>更多细节请查看 <a href="https://github.com/wangweiProtocol/wwp" style="color:#0ff">GitHub仓库</a></p>
        <button class="btn-neon" id="closeModalBtn" style="margin-top: 16px;">关闭</button>
    </div>
</div>

<script src="demo.js"></script>
</body>
</html>