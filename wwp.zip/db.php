<?php
// db.php
require_once __DIR__ . '/config.php';

class DB {
    private static $pdo = null;
    public static function get() {
        if (self::$pdo === null) {
            self::$pdo = new PDO('sqlite:' . DB_PATH);
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            self::init();
        }
        return self::$pdo;
    }
    private static function init() {
        $db = self::$pdo;
        // 用户表
        $db->exec("CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at INTEGER
        )");
        // 消息表（收件箱/发件箱）
        $db->exec("CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            to_username TEXT NOT NULL,
            from_username TEXT NOT NULL,
            subject TEXT,
            content TEXT NOT NULL,
            is_read INTEGER DEFAULT 0,
            created_at INTEGER,
            parent_id INTEGER DEFAULT 0
        )");
        // 公告表
        $db->exec("CREATE TABLE IF NOT EXISTS announcements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER
        )");
        // 离线消息表（即时通讯备用）
        $db->exec("CREATE TABLE IF NOT EXISTS offline_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            to_username TEXT NOT NULL,
            from_username TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp INTEGER
        )");
        // AI 对话历史表（新增）
        $db->exec("CREATE TABLE IF NOT EXISTS ai_chat_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER
        )");
        // 插入默认公告（可选）
        $stmt = $db->query("SELECT COUNT(*) FROM announcements");
        if ($stmt->fetchColumn() == 0) {
            $db->exec("INSERT INTO announcements (title, content, created_at) VALUES 
                ('WWP 跨AI通讯协议演示站', '本站支持跨站消息收发、AI智能助手、端到端加密。欢迎体验！', " . time() . ")");
        }
    }
}
?>